// ================================================
// 2026 월드컵 페어플레이 관찰 기록 — Apps Script 백엔드
// ================================================
// 배포: 확장 프로그램 > Apps Script > 배포 > 새 배포
//       유형: 웹 앱 / 실행 계정: 나 / 액세스: 모든 사용자
// ================================================

// 수업 코드를 정규화 (공백·슬래시·따옴표 → 하이픈)
function normalizeCode(code) {
  return String(code || "")
    .trim()
    .replace(/[\s/\\'"]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "")
    .toLowerCase();
}

// 시트 이름은 최대 100자 + 예약 문자 제거
function sheetName(code) {
  return ("기록_" + code).slice(0, 100).replace(/[:\\/\[\]*?]/g, "");
}

// 해당 코드의 시트를 가져오거나 없으면 새로 만들기
function getOrCreateSheet(ss, code) {
  var name = sheetName(code);
  var sheet = ss.getSheetByName(name);
  if (!sheet) {
    sheet = ss.insertSheet(name);
    sheet.appendRow([
      "제출시각", "수업코드", "학반", "이름",
      "팀A", "팀B",
      "악수·인사(A)", "부상중단(A)", "상대일으킴(A)", "판정승복(A)", "절제세리머니(A)",
      "패자위로(A)", "정직양보(A)", "최선(A)", "의무팀배려(A)", "국가존중(A)", "합계(A)",
      "악수·인사(B)", "부상중단(B)", "상대일으킴(B)", "판정승복(B)", "절제세리머니(B)",
      "패자위로(B)", "정직양보(B)", "최선(B)", "의무팀배려(B)", "국가존중(B)", "합계(B)",
      "메모"
    ]);
    // 헤더 스타일
    var header = sheet.getRange(1, 1, 1, sheet.getLastColumn());
    header.setBackground("#0f3460");
    header.setFontColor("white");
    header.setFontWeight("bold");
    sheet.setFrozenRows(1);
  }
  return sheet;
}

// CORS 허용 헤더 포함 JSON 응답
function jsonResponse(data) {
  var output = ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
  return output;
}

// ── POST: 학생 제출 ──
function doPost(e) {
  try {
    var body = JSON.parse(e.postData.contents);
    var code = normalizeCode(body.code);

    if (!code) {
      return jsonResponse({ ok: false, error: "수업 코드가 없습니다." });
    }

    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var sheet = getOrCreateSheet(ss, code);

    var ca = body.countsA || {};
    var cb = body.countsB || {};
    var ids = ["fp1","fp2","fp3","fp4","fp5","fp6","fp7","fp8","fp9","fp10"];

    var row = [
      new Date().toLocaleString("ko-KR"),
      code,
      body.cls || "",
      body.name || "",
      body.teamA || "",
      body.teamB || ""
    ];

    // 팀 A 항목별 카운트
    ids.forEach(function(id) { row.push(Number(ca[id] || 0)); });
    row.push(Number(body.totalA || 0));

    // 팀 B 항목별 카운트
    ids.forEach(function(id) { row.push(Number(cb[id] || 0)); });
    row.push(Number(body.totalB || 0));

    row.push(body.memo || "");

    sheet.appendRow(row);

    return jsonResponse({ ok: true, message: "제출 완료" });

  } catch (err) {
    return jsonResponse({ ok: false, error: err.message });
  }
}

// ── GET: 교사용 조회 또는 교사용 HTML 서빙 ──
function doGet(e) {
  var action = (e.parameter && e.parameter.action) || "";

  // action=query: 수업 코드별 기록 조회 (JSON)
  if (action === "query") {
    return doQuery(e);
  }

  // action=delete: 행 삭제
  if (action === "delete") {
    return doDelete(e);
  }

  // 기본: 교사용 웹페이지 서빙
  return HtmlService
    .createHtmlOutputFromFile("교사용_조회")
    .setTitle("페어플레이 관찰 기록 조회")
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function doQuery(e) {
  try {
    var code = normalizeCode(e.parameter.code);
    if (!code) {
      return jsonResponse({ ok: false, error: "수업 코드가 없습니다." });
    }

    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var name = sheetName(code);
    var sheet = ss.getSheetByName(name);
    if (!sheet) {
      return jsonResponse({ ok: true, records: [], total: 0 });
    }

    var data = sheet.getDataRange().getValues();
    var headers = data[0];
    var records = [];

    for (var i = 1; i < data.length; i++) {
      var row = data[i];
      if (!row[3]) continue; // 이름 없는 행 건너뜀
      var record = {};
      headers.forEach(function(h, idx) {
        record[h] = row[idx];
      });
      record["_row"] = i + 1; // 1-indexed 시트 행 번호 (삭제 시 사용)
      records.push(record);
    }

    // 최신 순 정렬
    records.reverse();

    return jsonResponse({ ok: true, records: records, total: records.length });

  } catch (err) {
    return jsonResponse({ ok: false, error: err.message });
  }
}

function doDelete(e) {
  try {
    var code = normalizeCode(e.parameter.code);
    var rowNum = parseInt(e.parameter.row, 10);
    if (!code || !rowNum) {
      return jsonResponse({ ok: false, error: "잘못된 요청입니다." });
    }

    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var name = sheetName(code);
    var sheet = ss.getSheetByName(name);
    if (!sheet) {
      return jsonResponse({ ok: false, error: "시트를 찾을 수 없습니다." });
    }

    sheet.deleteRow(rowNum);
    return jsonResponse({ ok: true, message: "삭제 완료" });

  } catch (err) {
    return jsonResponse({ ok: false, error: err.message });
  }
}
